package com.example.Tarea_Slider;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.imageslider.R;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

public class MainActivity extends AppCompatActivity {

    Button enviar;


    SliderView sliderView;
    int[] images = {R.drawable.merlina1,
    R.drawable.merlina2,
    R.drawable.merlina3,
    R.drawable.merlina4,
    R.drawable.merlina5,
    R.drawable.merlina6};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sliderView = findViewById(R.id.image_slider);

        SliderAdapter sliderAdapter = new SliderAdapter(images);

        sliderView.setSliderAdapter(sliderAdapter);
        sliderView.setIndicatorAnimation(IndicatorAnimationType.WORM);
        sliderView.setSliderTransformAnimation(SliderAnimations.DEPTHTRANSFORMATION);
        sliderView.startAutoCycle();


        enviar= findViewById(R.id.button);
        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    String URLSITIO = "https://www.netflix.com/sv/title/81231974";
                    String parametro = Uri.encode(URLSITIO,"UTF-8");
                    Intent navegador = new Intent(Intent.CATEGORY_BROWSABLE, Uri.parse(Uri.decode(parametro)));
                    navegador.setAction(Intent.ACTION_VIEW);
                    startActivity(navegador);
                }catch (Exception error){
                    Log.e("errorAbrir",error.getMessage());
                }

            }
        });


    }

}

